import os
from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import (
    LoginManager, UserMixin, login_user, login_required,
    logout_user, current_user
)
from dotenv import load_dotenv, find_dotenv

# LangChain + Groq Imports
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate
from langchain.chains import ConversationalRetrievalChain
from langchain_groq import ChatGroq

# ----------------------------
# Flask App Configuration
# ----------------------------
load_dotenv(find_dotenv())

app = Flask(__name__)
app.secret_key = "super_secret_key"  # change for production
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///users.db"

db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

# ----------------------------
# User Model
# ----------------------------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ----------------------------
# VectorStore + LLM Chain
# ----------------------------
DB_FAISS_PATH = "vectorstore/db_faiss"

def get_vectorstore():
    embedding_model = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    return FAISS.load_local(DB_FAISS_PATH, embedding_model, allow_dangerous_deserialization=True)

CUSTOM_PROMPT_TEMPLATE = """
You are MediBot — a friendly, professional, and knowledgeable AI medical assistant.

Guidelines:
- Only answer health-related questions using the provided context.
- Politely refuse questions unrelated to medical or health topics.
- Your response should be clear, empathetic, and user-friendly.
- Follow this structured format in your answer:

1. **Explanation**: Briefly explain the medical issue or symptom in simple language so the user can understand it.
2. **Practical Health Tips**: Provide 2–3 actionable tips the user can follow safely at home.
3. **Consultation Advice**: Suggest when the user should consult a doctor or healthcare professional for further guidance.

Conversation Context:
{chat_history}

Medical Context:
{context}

User Question:
{question}

Answer:
"""

vectorstore = get_vectorstore()

prompt = PromptTemplate(
    template=CUSTOM_PROMPT_TEMPLATE,
    input_variables=["context", "question", "chat_history"]
)

qa_chain = ConversationalRetrievalChain.from_llm(
    llm=ChatGroq(
        model_name="meta-llama/llama-4-maverick-17b-128e-instruct",
        temperature=0.0,
        groq_api_key=os.environ["GROQ_API_KEY"],
    ),
    retriever=vectorstore.as_retriever(search_kwargs={'k': 3}),
    return_source_documents=True,
    combine_docs_chain_kwargs={'prompt': prompt}
)

# ----------------------------
# Per-user Chat History
# ----------------------------
chat_history_dict = {}  # key = user_id

# ----------------------------
# Protect All Routes
# ----------------------------
@app.before_request
def require_login():
    allowed_routes = ['login', 'register', 'static']
    if request.endpoint not in allowed_routes and not current_user.is_authenticated:
        return redirect(url_for('login'))

# ----------------------------
# Auth Routes
# ----------------------------
@app.route("/")
def home():
    if current_user.is_authenticated:
        return redirect(url_for("chat_page"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            return render_template("register.html", error="All fields are required")

        if User.query.filter_by(username=username).first():
            return render_template("register.html", error="Username already exists")

        hashed_pw = bcrypt.generate_password_hash(password).decode("utf-8")
        new_user = User(username=username, password=hashed_pw)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        user = User.query.filter_by(username=username).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for("chat_page"))
        else:
            return render_template("login.html", error="Invalid username or password")

    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# ----------------------------
# Chat Routes
# ----------------------------
@app.route("/chat_ui")
@login_required
def chat_page():
    return render_template("index.html", username=current_user.username)

@app.route("/chat", methods=["POST"])
@login_required
def chat():
    user_input = request.json.get("message", "")
    if not user_input:
        return jsonify({"error": "No message provided"}), 400

    user_id = current_user.id
    if user_id not in chat_history_dict:
        chat_history_dict[user_id] = []

    user_history = chat_history_dict[user_id]
    formatted_history = [
        ("human" if msg["role"] == "user" else "ai", msg["content"])
        for msg in user_history
    ]

    try:
        response = qa_chain({
            "question": user_input,
            "chat_history": formatted_history
        })
        answer = response["answer"]

        user_history.append({"role": "user", "content": user_input})
        user_history.append({"role": "assistant", "content": answer})

        return jsonify({"reply": answer})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/history")
@login_required
def history():
    return jsonify(chat_history_dict.get(current_user.id, []))

# ----------------------------
# Initialize DB
# ----------------------------
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)
